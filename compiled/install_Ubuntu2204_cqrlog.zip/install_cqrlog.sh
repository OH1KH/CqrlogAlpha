#!/bin/bash
clear
echo "Installing official Cqrlog 2.5.2 for Ubuntu 22.04 with MariaDB database."
echo "At the end of install you may do upgrade right away to latest CqrlogAlpha"
echo "version either using GTK2 or QT5 graphics, if you like."
echo ...
echo ...
echo ...
echo "NEXT:"
echo "Making cleanup first. Press enter to continue, Ctrl+C to stop"
read input
clear
cd /tmp
# remove files from possible previous run use sudo & -f(orce) to get them all out
sudo rm -f cqr*.*
sudo rm -f version.*
sudo rm -f newupd*.*
sudo rm -f help.tgz
echo ...
echo ...
echo ...
echo "NEXT:"
echo "Installing dependencies first. Press enter to continue, Ctrl+C to stop"
read input
clear

sudo apt install libhamlib-utils libhamlib4 libmariadb-dev-compat libatk1.0-0 libcairo2 libgdk-pixbuf-2.0-0 libglib2.0-0 libgtk2.0-0 libpango-1.0-0 libx11-6 xplanet mariadb-client mariadb-server mariadb-common trustedqsl libssl-dev libqt5pas1

echo ...
echo ...
echo ...
echo "NEXT:"
echo "Downloading Cqrlog 2.5.2 Press enter to continue, Ctrl+C to stop"
read input
clear
cd /tmp
wget -q --show-progress  https://github.com/ok2cqr/cqrlog/releases/download/v2.5.2/cqrlog_2.5.2_amd64.tar.gz
echo ...
echo ...
echo ...
echo "NEXT:"
echo "Installing Cqrlog 2.5.2 Press enter to continue, Ctrl+C to stop"
read input
clear
cd /
sudo tar -vxf /tmp/cqrlog_2.5.2_amd64.tar.gz --strip-components=1
echo ...
echo ...
echo ...
echo "NEXT:"
echo "You can now upgrade to CqrlogAlpha right away, if you like!"
echo "Press Enter continue, Ctrl+C to deny and stop this script"
read input
clear
echo ...
echo ...
echo ...
echo "NEXT:"
echo "Downloading upgrade script Press enter to continue, Ctrl+C to stop"
read input
clear
cd /tmp
wget -q --show-progress  https://github.com/oh1kh/CqrlogAlpha/raw/refs/heads/main/compiled/newupdate.zip
wget -q --show-progress  https://github.com/oh1kh/CqrlogAlpha/raw/refs/heads/main/compiled/version.txt
unzip /tmp/newupdate.zip -d /tmp
chmod a+x /tmp/newupdate.sh
ver=$(cat /tmp/version.txt)
# if Cqrlog is never started we need user's folder to run newupdate.sh. Even if empty
if [ ! -d ~/.config/cqrlog ]; then
  touch ~/.config/cqrlog
  madeit="yes"
 else
  madeit="no" 
fi
echo ...
echo ...
echo ...
echo "NEXT:"
echo "Running upgrade script to install Cqrlog"$ver
echo
echo "When asked to 'Make your selection' you can answer:"
echo " 1 (GTK2 graphics)   or    2 (QT5 graphics)."
echo
echo "Press Enter continue"
read input
clear

source /tmp/newupdate.sh

# if .config/cqrlog is empty, remove it.
if [ $madeit == "yes" ];then 
    rm -rf ~/.config/cqrlog
fi
echo ...
echo ...
echo ...
echo "NEXT:"
echo "Trying to start your Cqrlog"$ver" from command console"
echo
echo "Press Enter continue"
read input
clear
cqrlog
