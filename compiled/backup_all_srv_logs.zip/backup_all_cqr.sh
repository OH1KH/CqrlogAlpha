#!/bin/bash

stamp=$(date +_%Y%m%d-%H%M)
echo -e "\nStarted$stamp"
echo -e "Creating common backup of all CQRLOG logs in database to /tmp/allcqrlogs$stamp.sql"
$(mysql -ucqrlog -poh1kh -B -N -hlocalhost -P3306 -e " show databases like 'cqr%'" |\
xargs  echo -n mysqldump -q -hlocalhost -P3306 -ucqrlog -poh1kh --databases) > /tmp/allcqrlogs$stamp.sql
echo -e "Creating separate backups of each CQRLOG logXXX in database to /tmp/cqrlogXXX$stamp.sql(s)\n"
mysql -ucqrlog -poh1kh -B -N -hlocalhost -P3306 -e " show databases like 'cqr%'" |\
xargs -d\ | while read line; do if [[ $line != "" ]];then\
 echo "mysqldump -q -hlocalhost -P3306 -ucqrlog -poh1kh $line > /tmp/$line$stamp.sql";fi;done > /tmp/sepsql.sh
chmod a+x /tmp/sepsql.sh
/tmp/sepsql.sh
rm /tmp/sepsql.sh
echo -e "\nDone!\nCopy backup files to your safe place.\nThey will be erased from /tmp at next Linux start\n\n"
echo "To restore all CQRLOG logs use command:"
echo -e "mysql -hlocalhost -P3306 -ucqrlog -poh1kh < /tmp/allcqrlogs$stamp.sql\n\n"
echo "To restore single a log use command:"
echo "mysql -hlocalhost -P3306 -ucqrlog -poh1kh cqrlog001 < /tmp/cqrlog001$stamp.sql"
echo -e "\nBe sure that both log numbers used in line are equal"
